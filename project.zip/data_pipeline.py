from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


TARGET_COLUMN = "silent_failure"
ID_COLUMNS = ["shipment_id"]

CATEGORICAL_FEATURES = [
    "package_type",
    "carrier_id",
    "origin_zone",
    "dest_zone",
]

NUMERIC_FEATURES = [
    "transit_days",
    "door_opens",
    "temp_mean_c",
    "temp_max_c",
    "temp_min_c",
    "temp_std_c",
    "temp_recovery_rate",
    "rh_mean",
    "rh_std",
    "rh_max",
    "product_volume_l",
    "fill_ratio",
    "leg_count",
    "sensor_gap_hours",
    "vibration_index",
    "feature_x1",
    "feature_x2",
    "feature_x3",
]

DEFAULT_FEATURE_COLUMNS = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def clean_column_name(name: object) -> str:
    text = str(name).strip().lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    return df.rename(columns={col: clean_column_name(col) for col in df.columns})


def load_dataset(csv_path: str | Path) -> pd.DataFrame:
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    df = pd.read_csv(path)
    df = normalize_columns(df)
    df = df.dropna(how="all").drop_duplicates(keep="last")
    return coerce_known_types(df)


def coerce_known_types(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()

    for col in NUMERIC_FEATURES:
        if col in result.columns:
            result[col] = pd.to_numeric(result[col], errors="coerce")

    for col in CATEGORICAL_FEATURES:
        if col in result.columns:
            result[col] = result[col].astype("string").fillna("unknown")

    if TARGET_COLUMN in result.columns:
        result[TARGET_COLUMN] = pd.to_numeric(result[TARGET_COLUMN], errors="coerce")

    return result


def available_feature_columns(df: pd.DataFrame) -> list[str]:
    return [col for col in DEFAULT_FEATURE_COLUMNS if col in df.columns]


def ensure_feature_columns(df: pd.DataFrame, feature_columns: Iterable[str]) -> pd.DataFrame:
    result = normalize_columns(df.copy())

    for col in feature_columns:
        if col not in result.columns:
            result[col] = np.nan

    result = coerce_known_types(result)
    return result[list(feature_columns)]


def build_training_frame(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, list[str], list[str], list[str]]:
    if TARGET_COLUMN not in df.columns:
        raise ValueError(f"Dataset must contain target column: {TARGET_COLUMN}")

    feature_columns = available_feature_columns(df)
    if not feature_columns:
        raise ValueError("No supported feature columns found in dataset.")

    y = pd.to_numeric(df[TARGET_COLUMN], errors="coerce")
    mask = y.notna()

    X = ensure_feature_columns(df.loc[mask], feature_columns)
    y = y.loc[mask].astype(int)

    numeric_features = [col for col in NUMERIC_FEATURES if col in feature_columns]
    categorical_features = [col for col in CATEGORICAL_FEATURES if col in feature_columns]

    return X, y, feature_columns, numeric_features, categorical_features


def guess_timestamp_column(df: pd.DataFrame) -> str | None:
    for col in ["timestamp", "time", "datetime", "date", "event_time", "created_at", "ts"]:
        if col in df.columns:
            return col
    return None


def guess_shipment_column(df: pd.DataFrame) -> str | None:
    for col in ["shipment_id", "shipment", "shipmentid", "id", "order_id"]:
        if col in df.columns:
            return col
    return df.columns[0] if len(df.columns) else None


def guess_temperature_column(df: pd.DataFrame) -> str | None:
    for col in [
        "temperature",
        "temp",
        "temp_c",
        "temperature_c",
        "t",
        "temp_mean_c",
        "temp_min_c",
        "temp_max_c",
    ]:
        if col in df.columns:
            return col

    numeric_cols = [col for col in df.columns if pd.api.types.is_numeric_dtype(df[col])]
    return numeric_cols[0] if numeric_cols else None


def dedupe_for_streaming(df: pd.DataFrame, shipment_col: str | None, ts_col: str | None) -> pd.DataFrame:
    if shipment_col and ts_col and shipment_col in df.columns and ts_col in df.columns:
        return df.drop_duplicates(subset=[shipment_col, ts_col], keep="last")
    return df.drop_duplicates(keep="last")
