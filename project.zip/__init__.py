"""Cold-chain realtime monitoring package."""
