from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


SCHEMA = """
CREATE TABLE IF NOT EXISTS temperature_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id TEXT,
    event_timestamp TEXT,
    temperature REAL,
    status TEXT NOT NULL,
    reason TEXT,
    risk_score REAL,
    risk_level TEXT,
    model_label INTEGER,
    model_probability REAL,
    model_version TEXT,
    source_key TEXT,
    raw_payload TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_temperature_logs_created_at
ON temperature_logs(created_at);

CREATE INDEX IF NOT EXISTS idx_temperature_logs_shipment_id
ON temperature_logs(shipment_id);

CREATE INDEX IF NOT EXISTS idx_temperature_logs_status
ON temperature_logs(status);
"""


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _source_key_from_payload(raw_payload: Any) -> str:
    payload_json = json.dumps(raw_payload, ensure_ascii=False, default=str, sort_keys=True)
    return hashlib.sha256(payload_json.encode("utf-8")).hexdigest()


def initialize_database(db_path: str | Path) -> None:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with sqlite3.connect(path) as conn:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.executescript(SCHEMA)
        columns = {row[1] for row in conn.execute("PRAGMA table_info(temperature_logs)").fetchall()}
        if "source_key" not in columns:
            conn.execute("ALTER TABLE temperature_logs ADD COLUMN source_key TEXT")
        conn.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_temperature_logs_source_key
            ON temperature_logs(source_key)
            """
        )
        conn.commit()


def insert_temperature_log(db_path: str | Path, event: Mapping[str, Any]) -> int:
    initialize_database(db_path)

    raw_payload = event.get("raw_features") or dict(event)
    raw_payload_json = json.dumps(raw_payload, ensure_ascii=False, default=str)
    source_key = event.get("source_key") or _source_key_from_payload(raw_payload)
    created_at = utc_now_iso()
    shipment_id = event.get("shipment_id")
    event_timestamp = event.get("timestamp")

    with sqlite3.connect(db_path) as conn:
        existing = None
        if source_key:
            existing = conn.execute(
                """
                SELECT id
                FROM temperature_logs
                WHERE source_key = ?
                ORDER BY id DESC
                LIMIT 1
                """,
                (source_key,),
            ).fetchone()

        if existing is None and shipment_id and event_timestamp:
            existing = conn.execute(
                """
                SELECT id
                FROM temperature_logs
                WHERE shipment_id = ? AND event_timestamp = ?
                ORDER BY id DESC
                LIMIT 1
                """,
                (shipment_id, event_timestamp),
            ).fetchone()

        if existing is not None:
            log_id = int(existing[0])
            conn.execute(
                """
                UPDATE temperature_logs
                SET
                    shipment_id = ?,
                    event_timestamp = ?,
                    temperature = ?,
                    status = ?,
                    reason = ?,
                    risk_score = ?,
                    risk_level = ?,
                    model_label = ?,
                    model_probability = ?,
                    model_version = ?,
                    source_key = ?,
                    raw_payload = ?
                WHERE id = ?
                """,
                (
                    shipment_id,
                    event_timestamp,
                    event.get("temperature"),
                    event.get("status"),
                    event.get("reason"),
                    event.get("risk_score"),
                    event.get("risk_level"),
                    event.get("silent_failure_prediction"),
                    event.get("silent_failure_probability"),
                    event.get("model_version"),
                    source_key,
                    raw_payload_json,
                    log_id,
                ),
            )
            conn.commit()
            return log_id

        cursor = conn.execute(
            """
            INSERT INTO temperature_logs (
                shipment_id,
                event_timestamp,
                temperature,
                status,
                reason,
                risk_score,
                risk_level,
                model_label,
                model_probability,
                model_version,
                source_key,
                raw_payload,
                created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                shipment_id,
                event_timestamp,
                event.get("temperature"),
                event.get("status"),
                event.get("reason"),
                event.get("risk_score"),
                event.get("risk_level"),
                event.get("silent_failure_prediction"),
                event.get("silent_failure_probability"),
                event.get("model_version"),
                source_key,
                raw_payload_json,
                created_at,
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)


def export_temperature_logs_to_csv(db_path: str | Path, csv_path: str | Path) -> int:
    initialize_database(db_path)
    destination = Path(csv_path)
    destination.parent.mkdir(parents=True, exist_ok=True)

    columns = [
        "id",
        "shipment_id",
        "event_timestamp",
        "temperature",
        "status",
        "reason",
        "risk_score",
        "risk_level",
        "model_label",
        "model_probability",
        "model_version",
        "source_key",
        "raw_payload",
        "created_at",
    ]

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            f"""
            SELECT {", ".join(columns)}
            FROM temperature_logs
            ORDER BY id ASC
            """
        ).fetchall()

    with destination.open("w", encoding="utf-8-sig", newline="") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=columns)
        writer.writeheader()
        writer.writerows(dict(row) for row in rows)

    return len(rows)


def fetch_recent_logs(db_path: str | Path, limit: int = 50) -> list[dict[str, Any]]:
    initialize_database(db_path)

    limit = max(1, min(int(limit), 500))
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            SELECT
                id,
                shipment_id,
                event_timestamp,
                temperature,
                status,
                reason,
                risk_score,
                risk_level,
                model_label,
                model_probability,
                model_version,
                source_key,
                created_at
            FROM temperature_logs
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def fetch_summary(db_path: str | Path) -> dict[str, Any]:
    initialize_database(db_path)

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'OK' THEN 1 ELSE 0 END) AS ok_count,
                SUM(CASE WHEN status = 'WARN' THEN 1 ELSE 0 END) AS warn_count,
                SUM(CASE WHEN status = 'ALERT' THEN 1 ELSE 0 END) AS alert_count,
                SUM(CASE WHEN risk_level = 'HIGH' THEN 1 ELSE 0 END) AS high_risk_count,
                MAX(created_at) AS last_created_at
            FROM temperature_logs
            """
        ).fetchone()

    result = dict(row)
    for key in ["total", "ok_count", "warn_count", "alert_count", "high_risk_count"]:
        result[key] = int(result[key] or 0)
    return result
