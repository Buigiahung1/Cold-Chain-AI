from __future__ import annotations

from datetime import datetime
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping

try:
    import firebase_admin
    from firebase_admin import credentials, firestore, messaging
except Exception:  # firebase-admin is optional until Firebase is enabled
    firebase_admin = None
    credentials = None
    firestore = None
    messaging = None

from config import Settings


class FirebaseSyncService:
    """Optional Firebase integration for Firestore sync + FCM push notifications.

    The application still works normally with SQLite when Firebase is not configured.
    Enable Firebase by setting COLDCHAIN_FIREBASE_ENABLED=true and providing a
    Firebase service-account JSON file path through COLDCHAIN_FIREBASE_CREDENTIALS.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client = None
        self.app = None
        self.enabled = settings.firebase_enabled
        self.load_error: str | None = None
        self.load()

    @property
    def available(self) -> bool:
        return self.enabled and self.client is not None

    @property
    def fcm_available(self) -> bool:
        return self.enabled and self.app is not None and messaging is not None

    def load(self) -> None:
        self.client = None
        self.app = None
        self.load_error = None

        if not self.enabled:
            return

        if firebase_admin is None or credentials is None or firestore is None or messaging is None:
            self.load_error = "Thiếu thư viện firebase-admin. Chạy: pip install -r requirements.txt"
            return

        if self.settings.firebase_credentials_path is None:
            self.load_error = "Thiếu đường dẫn service-account JSON. Đặt file firebase-service-account.json cạnh app.py hoặc sửa COLDCHAIN_FIREBASE_CREDENTIALS trong .env.macos."
            return

        cred_path = Path(self.settings.firebase_credentials_path)
        if not cred_path.exists():
            self.load_error = f"Không thấy file Firebase service account: {cred_path}. Tải file từ Firebase Console và đặt tên firebase-service-account.json cạnh app.py."
            return

        try:
            app_name = "cold_chain_ai"
            existing_apps = {app.name: app for app in firebase_admin._apps.values()}
            if app_name in existing_apps:
                app = existing_apps[app_name]
            else:
                cred = credentials.Certificate(str(cred_path))
                options: dict[str, Any] = {}
                if self.settings.firebase_database_url:
                    options["databaseURL"] = self.settings.firebase_database_url
                app = firebase_admin.initialize_app(cred, options=options, name=app_name)

            self.app = app
            self.client = firestore.client(app=app)
        except Exception as exc:
            self.load_error = str(exc)

    def info(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "available": self.available,
            "fcm_available": self.fcm_available,
            "web_push_configured": self.settings.firebase_web_push_configured,
            "missing_web_push_fields": getattr(self.settings, "missing_firebase_web_push_fields", []),
            "collection": self.settings.firebase_collection,
            "alerts_collection": self.settings.firebase_alerts_collection,
            "tokens_collection": self.settings.firebase_fcm_tokens_collection,
            "only_alerts": self.settings.firebase_only_alerts,
            "load_error": self.load_error,
        }

    def push_event(self, event: Mapping[str, Any]) -> dict[str, Any]:
        """Push one realtime event to Firestore.

        Returns a small status dictionary. Failures are isolated so Firebase does
        not break the local SQLite + dashboard flow.
        """

        if not self.enabled:
            return {"ok": False, "skipped": True, "reason": "firebase_disabled"}
        if not self.available or self.client is None:
            return {"ok": False, "skipped": True, "reason": self.load_error or "firebase_unavailable"}

        status = str(event.get("status", ""))
        if self.settings.firebase_only_alerts and status not in {"WARN", "ALERT"}:
            return {"ok": False, "skipped": True, "reason": "only_alerts_enabled"}

        try:
            data = _firebase_safe_dict(event)
            data["synced_at"] = datetime.utcnow().isoformat() + "Z"

            doc_id = _doc_id_from_event(event)
            self.client.collection(self.settings.firebase_collection).document(doc_id).set(data, merge=True)

            if status in {"WARN", "ALERT"}:
                self.client.collection(self.settings.firebase_alerts_collection).document(doc_id).set(data, merge=True)

            return {"ok": True, "skipped": False, "doc_id": doc_id}
        except Exception as exc:
            return {"ok": False, "skipped": False, "reason": str(exc)}

    def register_fcm_token(self, token: str, user_agent: str | None = None) -> dict[str, Any]:
        """Save a browser/device FCM token so the backend can push alerts to it."""

        token = (token or "").strip()
        if not token:
            return {"ok": False, "reason": "missing_token"}
        if not self.enabled:
            return {"ok": False, "reason": "firebase_disabled"}
        if not self.available or self.client is None:
            return {"ok": False, "reason": self.load_error or "firebase_unavailable"}

        try:
            doc_id = sha256(token.encode("utf-8")).hexdigest()
            self.client.collection(self.settings.firebase_fcm_tokens_collection).document(doc_id).set(
                {
                    "token": token,
                    "user_agent": user_agent or "",
                    "updated_at": datetime.utcnow().isoformat() + "Z",
                    "active": True,
                },
                merge=True,
            )
            return {"ok": True, "token_id": doc_id[:12]}
        except Exception as exc:
            return {"ok": False, "reason": str(exc)}

    def send_alert_notification(self, event: Mapping[str, Any]) -> dict[str, Any]:
        """Send an FCM push notification to all registered browser tokens."""

        status = str(event.get("status", ""))
        if status not in {"WARN", "ALERT"}:
            return {"ok": False, "skipped": True, "reason": "not_an_alert"}
        if not self.enabled:
            return {"ok": False, "skipped": True, "reason": "firebase_disabled"}
        if not self.fcm_available:
            return {"ok": False, "skipped": True, "reason": self.load_error or "fcm_unavailable"}
        if not self.available or self.client is None:
            return {"ok": False, "skipped": True, "reason": self.load_error or "firebase_unavailable"}

        try:
            token_docs = (
                self.client.collection(self.settings.firebase_fcm_tokens_collection)
                .where("active", "==", True)
                .limit(500)
                .stream()
            )
            token_rows = [(doc.id, doc.to_dict().get("token")) for doc in token_docs]
            tokens = [str(token) for _, token in token_rows if token]
            if not tokens:
                return {"ok": False, "skipped": True, "reason": "no_registered_tokens"}

            shipment_id = str(event.get("shipment_id") or "Unknown shipment")
            temperature = event.get("temperature")
            reason = str(event.get("reason") or "Temperature warning")
            title = f"{status}: Cold Chain cảnh báo"
            body = f"{shipment_id} | Temp: {temperature}°C | {reason}"

            message = messaging.MulticastMessage(
                notification=messaging.Notification(title=title, body=body),
                data={
                    "type": "cold_chain_alert",
                    "status": status,
                    "shipment_id": shipment_id,
                    "temperature": "" if temperature is None else str(temperature),
                    "reason": reason,
                    "timestamp": "" if event.get("timestamp") is None else str(event.get("timestamp")),
                    "risk_score": "" if event.get("risk_score") is None else str(event.get("risk_score")),
                    "risk_level": "" if event.get("risk_level") is None else str(event.get("risk_level")),
                    "url": "/",
                },
                webpush=messaging.WebpushConfig(
                    headers={"Urgency": "high"},
                    notification=messaging.WebpushNotification(
                        title=title,
                        body=body,
                        require_interaction=False,
                    ),
                ),
                # Không set WebpushFCMOptions.link khi chạy localhost.
                # Firebase Admin SDK bắt link là URL HTTPS tuyệt đối; "/" hoặc http://localhost sẽ bị lỗi.
                # Service Worker vẫn mở trang qua payload data["url"] khi người dùng bấm thông báo.
                tokens=tokens,
            )
            response = messaging.send_each_for_multicast(message, app=self.app)

            deleted = 0
            # Clean common dead tokens so future sends are less noisy.
            for index, send_response in enumerate(response.responses):
                if send_response.success:
                    continue
                error_text = str(send_response.exception or "")
                if "registration-token-not-registered" in error_text or "invalid-registration-token" in error_text:
                    doc_id = token_rows[index][0]
                    self.client.collection(self.settings.firebase_fcm_tokens_collection).document(doc_id).delete()
                    deleted += 1

            return {
                "ok": response.success_count > 0,
                "skipped": False,
                "success_count": response.success_count,
                "failure_count": response.failure_count,
                "deleted_invalid_tokens": deleted,
            }
        except Exception as exc:
            return {"ok": False, "skipped": False, "reason": str(exc)}


def _doc_id_from_event(event: Mapping[str, Any]) -> str:
    if event.get("log_id") is not None:
        return f"log_{event.get('log_id')}"
    shipment_id = str(event.get("shipment_id", "shipment"))
    timestamp = str(event.get("timestamp", "time")).replace(":", "-").replace(".", "-")
    return f"{shipment_id}_{timestamp}"[:1400]


def _firebase_safe_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _firebase_safe_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_firebase_safe_value(v) for v in value]
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    return str(value)


def _firebase_safe_dict(event: Mapping[str, Any]) -> dict[str, Any]:
    return {str(key): _firebase_safe_value(value) for key, value in event.items()}
