#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f ".env.macos" ]; then
  cp .env.macos.example .env.macos
  echo "Đã tạo .env.macos từ .env.macos.example."
  echo "Bạn cần điền Firebase Web Config và VAPID key vào .env.macos để nhận push notification."
fi

set -a
# shellcheck disable=SC1091
source .env.macos
set +a

if [ ! -d ".venv" ]; then
  ./setup_macos.sh
fi

source .venv/bin/activate
export PYTHONUNBUFFERED=1
PORT="${PORT:-8000}"

if [ ! -f "firebase-service-account.json" ]; then
  echo "CẢNH BÁO: Chưa thấy firebase-service-account.json cạnh app.py."
  echo "Firebase/FCM sẽ chưa chạy được cho tới khi bạn tải service account từ Firebase Console và đặt đúng tên file."
fi

if grep -q 'COLDCHAIN_FIREBASE_WEB_API_KEY=""' .env.macos; then
  echo "CẢNH BÁO: .env.macos chưa có Firebase Web Config/VAPID key."
  echo "Nút 'Bật thông báo Firebase' sẽ báo thiếu config cho tới khi bạn điền đủ." 
fi

echo "Server đang chạy ở: http://localhost:${PORT}"
echo "Lưu ý: mở đúng http://localhost:${PORT}, không mở static/index.html trực tiếp."
python -m uvicorn app:app --host 127.0.0.1 --port "$PORT" --reload
