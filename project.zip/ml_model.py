from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from data_pipeline import build_training_frame, ensure_feature_columns, load_dataset


MODEL_VERSION = "random_forest_v1"


def build_preprocessor(numeric_features: list[str], categorical_features: list[str]) -> ColumnTransformer:
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
        ]
    )
    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            # One-Hot Encoding: chuyển dữ liệu phân loại dạng chữ
            # như package_type, carrier_id, origin_zone, dest_zone
            # thành các cột số 0/1 để mô hình Random Forest học được.
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("num", numeric_pipeline, numeric_features),
            ("cat", categorical_pipeline, categorical_features),
        ],
        remainder="drop",
    )


def probability_to_level(probability: float | None) -> str | None:
    if probability is None:
        return None
    if probability >= 0.70:
        return "HIGH"
    if probability >= 0.35:
        return "MEDIUM"
    return "LOW"


def _positive_class_probability(pipeline: Pipeline, X: pd.DataFrame) -> list[float]:
    probabilities = pipeline.predict_proba(X)
    model = pipeline.named_steps["model"]
    classes = list(model.classes_)
    positive_index = classes.index(1) if 1 in classes else len(classes) - 1
    return [float(row[positive_index]) for row in probabilities]


def _top_feature_importances(pipeline: Pipeline, limit: int = 12) -> list[dict[str, float | str]]:
    model = pipeline.named_steps["model"]
    preprocessor = pipeline.named_steps["preprocess"]

    try:
        feature_names = list(preprocessor.get_feature_names_out())
    except Exception:
        feature_names = [f"feature_{idx}" for idx in range(len(model.feature_importances_))]

    ranked = sorted(zip(feature_names, model.feature_importances_), key=lambda item: item[1], reverse=True)
    return [{"feature": str(name), "importance": float(value)} for name, value in ranked[:limit]]


def train_random_forest(
    dataset_csv: str | Path,
    model_path: str | Path,
    metrics_path: str | Path | None = None,
    random_state: int = 42,
) -> dict[str, Any]:
    df = load_dataset(dataset_csv)
    X, y, feature_columns, numeric_features, categorical_features = build_training_frame(df)

    stratify = y if y.nunique() > 1 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=random_state,
        stratify=stratify,
    )

    pipeline = Pipeline(
        steps=[
            ("preprocess", build_preprocessor(numeric_features, categorical_features)),
            (
                "model",
                RandomForestClassifier(
                    n_estimators=300,
                    random_state=random_state,
                    class_weight="balanced",
                    min_samples_leaf=2,
                    n_jobs=-1,
                ),
            ),
        ]
    )
    pipeline.fit(X_train, y_train)

    y_pred = pipeline.predict(X_test)
    positive_probs = _positive_class_probability(pipeline, X_test)

    metrics = {
        "model_version": MODEL_VERSION,
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "dataset": str(Path(dataset_csv).resolve()),
        "rows": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "target_distribution": {str(key): int(value) for key, value in y.value_counts().sort_index().items()},
        "feature_columns": feature_columns,
        "numeric_features": numeric_features,
        "categorical_features": categorical_features,
        "categorical_encoding": "One-Hot Encoding",
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, positive_probs)) if y_test.nunique() > 1 else None,
        "confusion_matrix": confusion_matrix(y_test, y_pred).astype(int).tolist(),
        "top_feature_importances": _top_feature_importances(pipeline),
    }

    artifact = {
        "pipeline": pipeline,
        "metadata": metrics,
    }

    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifact, model_path)

    if metrics_path is not None:
        metrics_path = Path(metrics_path)
        metrics_path.parent.mkdir(parents=True, exist_ok=True)
        metrics_path.write_text(json.dumps(metrics, indent=2, ensure_ascii=False), encoding="utf-8")

    return metrics


class RiskModelService:
    def __init__(self, model_path: str | Path, threshold: float = 0.5) -> None:
        self.model_path = Path(model_path)
        self.threshold = threshold
        self.pipeline: Pipeline | None = None
        self.metadata: dict[str, Any] = {}
        self.load_error: str | None = None
        self.load()

    @property
    def available(self) -> bool:
        return self.pipeline is not None

    def load(self) -> None:
        self.pipeline = None
        self.metadata = {}
        self.load_error = None

        if not self.model_path.exists():
            self.load_error = f"Model file not found: {self.model_path}"
            return

        try:
            artifact = joblib.load(self.model_path)
            if isinstance(artifact, dict) and "pipeline" in artifact:
                self.pipeline = artifact["pipeline"]
                self.metadata = artifact.get("metadata", {})
            else:
                self.pipeline = artifact
                self.metadata = {"model_version": "legacy_model"}
        except Exception as exc:
            self.load_error = str(exc)

    def info(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "model_path": str(self.model_path),
            "threshold": self.threshold,
            "load_error": self.load_error,
            "metadata": self.metadata,
        }

    def predict(self, row: pd.Series | dict[str, Any]) -> dict[str, Any]:
        if not self.available or self.pipeline is None:
            return {
                "model_available": False,
                "model_error": self.load_error,
                "silent_failure_probability": None,
                "silent_failure_prediction": None,
                "model_version": None,
            }

        raw = row.to_dict() if isinstance(row, pd.Series) else dict(row)
        feature_columns = self.metadata.get("feature_columns")
        if not feature_columns:
            return {
                "model_available": False,
                "model_error": "Model metadata is missing feature_columns.",
                "silent_failure_probability": None,
                "silent_failure_prediction": None,
                "model_version": self.metadata.get("model_version"),
            }

        X = ensure_feature_columns(pd.DataFrame([raw]), feature_columns)
        probability = _positive_class_probability(self.pipeline, X)[0]
        label = int(probability >= self.threshold)

        return {
            "model_available": True,
            "model_error": None,
            "silent_failure_probability": probability,
            "silent_failure_prediction": label,
            "risk_score": round(probability * 100.0, 2),
            "risk_level": probability_to_level(probability),
            "model_version": self.metadata.get("model_version", MODEL_VERSION),
        }
