from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from itsdangerous import BadSignature, URLSafeTimedSerializer

from config import Settings, get_settings
from data_pipeline import (
    dedupe_for_streaming,
    guess_shipment_column,
    guess_temperature_column,
    guess_timestamp_column,
    load_dataset,
)
from database import (
    fetch_recent_logs,
    fetch_summary,
    initialize_database,
    insert_temperature_log,
)
from ml_model import RiskModelService
from firebase_sync import FirebaseSyncService


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    initialize_database(settings.database_path)

    app.state.settings = settings
    app.state.model_service = RiskModelService(settings.model_path, threshold=settings.model_threshold)
    app.state.firebase_service = FirebaseSyncService(settings)
    yield


app = FastAPI(
    title="Cold Chain Logistics - Random Forest Monitor",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


def _settings(request: Request) -> Settings:
    return request.app.state.settings


def _model_service(request: Request) -> RiskModelService:
    return request.app.state.model_service


def _firebase_service(request: Request) -> FirebaseSyncService:
    return request.app.state.firebase_service


def _firebase_web_public_payload(settings: Settings, firebase_service: FirebaseSyncService) -> dict[str, Any]:
    return {
        "enabled": bool(settings.firebase_enabled and firebase_service.fcm_available and settings.firebase_web_push_configured),
        "config": settings.firebase_web_config,
        "vapidKey": settings.firebase_web_vapid_key,
        "reason": None
        if bool(settings.firebase_enabled and firebase_service.fcm_available and settings.firebase_web_push_configured)
        else _firebase_web_missing_reason(settings, firebase_service),
    }


def _firebase_web_missing_reason(settings: Settings, firebase_service: FirebaseSyncService) -> str:
    if not settings.firebase_enabled:
        return "Firebase backend đang tắt. Trong .env.macos đặt COLDCHAIN_FIREBASE_ENABLED=true rồi chạy lại server."
    if not firebase_service.fcm_available:
        return firebase_service.load_error or "Firebase Admin/FCM chưa khả dụng."
    missing_fields = getattr(settings, "missing_firebase_web_push_fields", [])
    if missing_fields:
        return "Thiếu Firebase Web Config trong .env.macos: " + ", ".join(missing_fields) + ". Điền xong thì tắt server và chạy lại ./run_macos.sh."
    return "Firebase Web Push chưa sẵn sàng."


def _serializer(settings: Settings) -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(settings.auth_secret)


def _get_auth_username_from_cookie(request: Request, settings: Settings) -> str | None:
    cookie_val = request.cookies.get(settings.session_cookie)
    if not cookie_val:
        return None
    try:
        data = _serializer(settings).loads(cookie_val, max_age=60 * 60 * 8)
        return data.get("username")
    except BadSignature:
        return None


def _require_auth(request: Request, settings: Settings) -> bool:
    if not settings.auth_required:
        return True
    return _get_auth_username_from_cookie(request, settings) is not None


def _ensure_http_auth(request: Request) -> None:
    settings = _settings(request)
    if not _require_auth(request, settings):
        raise HTTPException(status_code=401, detail="Unauthorized")


def _require_auth_websocket(websocket: WebSocket, settings: Settings) -> bool:
    if not settings.auth_required:
        return True

    cookie_header = websocket.headers.get("cookie")
    if not cookie_header:
        return False

    cookies: dict[str, str] = {}
    for part in cookie_header.split(";"):
        if "=" in part:
            key, value = part.split("=", 1)
            cookies[key.strip()] = value.strip()

    cookie_val = cookies.get(settings.session_cookie)
    if not cookie_val:
        return False

    try:
        data = _serializer(settings).loads(cookie_val, max_age=60 * 60 * 8)
        return data.get("username") is not None
    except BadSignature:
        return False


def _json_safe(value: Any) -> Any:
    if value is None:
        return None

    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass

    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, datetime):
        return value.isoformat()
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            pass
    return value


def _row_to_dict(row: pd.Series) -> dict[str, Any]:
    return {str(key): _json_safe(value) for key, value in row.items()}


def _float_or_none(value: Any) -> float | None:
    value = _json_safe(value)
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _timestamp_from_row(row: pd.Series, ts_col: str | None) -> str:
    if ts_col and ts_col in row.index:
        raw = row[ts_col]
        ts = pd.to_datetime(raw, errors="coerce")
        if not pd.isna(ts):
            return ts.isoformat()
    return datetime.now(timezone.utc).isoformat()


def _combine_status(
    temp: float | None,
    prediction: dict[str, Any],
    settings: Settings,
) -> tuple[str, str, float | None, str | None]:
    """
    Phân loại trạng thái bằng kết quả dự đoán của Random Forest.

    Lưu ý:
    - Không đọc sẵn LOW/WARN/ALERT từ CSV.
    - Không dùng if/else theo nhiệt độ để gán cảnh báo.
    - Nhiệt độ và các biến cảm biến chỉ là feature đầu vào cho model.
    - Ngưỡng 0.35 và 0.70 chỉ dùng để hiển thị mức cảnh báo từ xác suất Random Forest.
    """
    if not prediction.get("model_available"):
        return "UNKNOWN", "RANDOM_FOREST_MODEL_NOT_AVAILABLE", None, None

    probability = prediction.get("silent_failure_probability")
    score = prediction.get("risk_score")
    level = prediction.get("risk_level")

    if probability is None:
        return "UNKNOWN", "RANDOM_FOREST_NO_PROBABILITY", score, level

    if probability >= 0.70:
        return "ALERT", "RANDOM_FOREST_HIGH_RISK", score, level
    if probability >= 0.35:
        return "WARN", "RANDOM_FOREST_MEDIUM_RISK", score, level
    return "OK", "RANDOM_FOREST_LOW_RISK", score, level


def _build_reading_payload(
    row: pd.Series,
    shipment_col: str | None,
    temp_col: str | None,
    ts_col: str | None,
) -> dict[str, Any]:
    temp = _float_or_none(row.get(temp_col)) if temp_col else None
    return {
        "shipment_id": str(row.get(shipment_col, "")) if shipment_col else "",
        "temperature": temp,
        "temperature_source": temp_col,
        "timestamp": _timestamp_from_row(row, ts_col),
        "temp_mean_c": _float_or_none(row.get("temp_mean_c")),
        "temp_min_c": _float_or_none(row.get("temp_min_c")),
        "temp_max_c": _float_or_none(row.get("temp_max_c")),
    }


@app.get("/", response_class=HTMLResponse)
async def index():
    return (STATIC_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/firebase-messaging-sw.js")
async def firebase_messaging_service_worker(request: Request):
    """Dynamic Firebase Messaging service worker served from the domain root."""

    settings = _settings(request)
    public_config = json.dumps(settings.firebase_web_config)
    js = f"""
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js');

const firebaseConfig = {public_config};

if (firebaseConfig && firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.messagingSenderId && firebaseConfig.appId) {{
  firebase.initializeApp(firebaseConfig);
  const messaging = firebase.messaging();

  messaging.onBackgroundMessage((payload) => {{
    const notification = payload.notification || {{}};
    const data = payload.data || {{}};
    const title = notification.title || `${{data.status || 'ALERT'}}: Cold Chain cảnh báo`;
    const body = notification.body || `${{data.shipment_id || ''}} | Temp: ${{data.temperature || 'N/A'}}°C | ${{data.reason || ''}}`;

    const detailData = {{
      title,
      body,
      status: data.status || '',
      shipment_id: data.shipment_id || '',
      timestamp: data.timestamp || '',
      temperature: data.temperature || '',
      reason: data.reason || '',
      risk_score: data.risk_score || '',
      risk_level: data.risk_level || '',
      source: 'fcm-background',
      url: data.url || '/'
    }};

    if (!detailData.url || detailData.url === '/') {{
      detailData.url = '/?notification_detail=' + encodeURIComponent(JSON.stringify(detailData));
    }}

    self.registration.showNotification(title, {{
      body,
      data: detailData,
      icon: '/static/favicon.ico'
    }});
  }});
}} else {{
  console.warn('Firebase web config is missing. Set COLDCHAIN_FIREBASE_WEB_* env variables.');
}}

self.addEventListener('notificationclick', (event) => {{
  event.notification.close();

  const rawUrl = (event.notification.data && event.notification.data.url) || '/';
  const targetUrl = rawUrl.startsWith('http') ? rawUrl : self.location.origin + rawUrl;

  event.waitUntil(
    clients.matchAll({{ type: 'window', includeUncontrolled: true }}).then((clientList) => {{
      for (const client of clientList) {{
        if (client.url.startsWith(self.location.origin)) {{
          if ('navigate' in client) {{
            return client.navigate(targetUrl).then((navigatedClient) => {{
              return navigatedClient ? navigatedClient.focus() : client.focus();
            }});
          }}
          return client.focus();
        }}
      }}

      if (clients.openWindow) {{
        return clients.openWindow(targetUrl);
      }}
    }})
  );
}});
""".strip()
    return Response(content=js, media_type="application/javascript")


@app.get("/auth/status")
async def auth_status(request: Request):
    settings = _settings(request)
    username = _get_auth_username_from_cookie(request, settings)
    return {
        "auth_required": settings.auth_required,
        "authenticated": True if not settings.auth_required else username is not None,
        "username": username,
    }


@app.post("/login")
async def login(request: Request):
    settings = _settings(request)
    if not settings.auth_required:
        return {"ok": True, "auth_required": False}

    body = await request.json()
    username = str(body.get("username", ""))
    password = str(body.get("password", ""))

    if username != settings.auth_user or password != settings.auth_pass:
        return {"ok": False, "message": "Sai username hoặc password."}

    signed = _serializer(settings).dumps({"username": username})
    resp = JSONResponse({"ok": True, "auth_required": True})
    resp.set_cookie(
        key=settings.session_cookie,
        value=signed,
        httponly=True,
        samesite="lax",
        secure=False,
        max_age=60 * 60 * 8,
    )
    return resp


@app.post("/logout")
async def logout(request: Request):
    settings = _settings(request)
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(settings.session_cookie)
    return resp


@app.get("/api/model")
async def model_info(request: Request):
    _ensure_http_auth(request)
    return _model_service(request).info()


@app.post("/api/model/reload")
async def reload_model(request: Request):
    _ensure_http_auth(request)
    model_service = _model_service(request)
    model_service.load()
    return model_service.info()


@app.get("/api/logs")
async def logs(request: Request, limit: int = 50):
    _ensure_http_auth(request)
    settings = _settings(request)
    return {"items": fetch_recent_logs(settings.database_path, limit=limit)}


@app.get("/api/summary")
async def summary(request: Request):
    _ensure_http_auth(request)
    settings = _settings(request)
    return fetch_summary(settings.database_path)


@app.get("/api/firebase")
async def firebase_info(request: Request):
    _ensure_http_auth(request)
    return _firebase_service(request).info()


@app.get("/api/firebase-web-config")
async def firebase_web_config(request: Request):
    _ensure_http_auth(request)
    settings = _settings(request)
    firebase_service = _firebase_service(request)
    return _firebase_web_public_payload(settings, firebase_service)


@app.post("/api/fcm/register")
async def register_fcm_token(request: Request):
    _ensure_http_auth(request)
    body = await request.json()
    token = str(body.get("token", ""))
    user_agent = request.headers.get("user-agent")
    return _firebase_service(request).register_fcm_token(token, user_agent=user_agent)




@app.get("/api/config")
async def runtime_config(request: Request):
    _ensure_http_auth(request)
    settings = _settings(request)
    return {
        "dataset_csv": str(settings.dataset_csv),
        "database_path": str(settings.database_path),
        "model_path": str(settings.model_path),
        "min_temp": settings.min_temp,
        "max_temp": settings.max_temp,
        "model_threshold": settings.model_threshold,
        "firebase_enabled": settings.firebase_enabled,
        "firebase_collection": settings.firebase_collection,
        "firebase_alerts_collection": settings.firebase_alerts_collection,
        "firebase_only_alerts": settings.firebase_only_alerts,
        "firebase_fcm_tokens_collection": settings.firebase_fcm_tokens_collection,
        "firebase_web_push_configured": settings.firebase_web_push_configured,
    }




async def stream_dataset(websocket: WebSocket, settings: Settings, model_service: RiskModelService, firebase_service: FirebaseSyncService, speed: float = 1.0):
    if not settings.dataset_csv.exists():
        await websocket.send_json({"type": "error", "message": f"Dataset not found: {settings.dataset_csv}"})
        return

    df = load_dataset(settings.dataset_csv)
    shipment_col = guess_shipment_column(df)
    temp_col = guess_temperature_column(df)
    ts_col = guess_timestamp_column(df)

    if shipment_col is None or temp_col is None:
        await websocket.send_json({"type": "error", "message": "Cannot detect shipment_id or temperature column."})
        return

    if ts_col and ts_col in df.columns:
        df = df.copy()
        df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
        df = df.sort_values(ts_col)

    df = dedupe_for_streaming(df, shipment_col, ts_col)
    prev_ts: pd.Timestamp | None = None
    streamed_count = 0

    await websocket.send_json(
        {
            "type": "meta",
            "total_rows": int(len(df)),
            "database_path": str(settings.database_path),
            "csv_path": None,
        }
    )

    for _, row in df.iterrows():
        row_ts = None
        if ts_col and ts_col in row.index:
            parsed = pd.to_datetime(row[ts_col], errors="coerce")
            row_ts = None if pd.isna(parsed) else parsed

        if prev_ts is not None and row_ts is not None:
            delta_sec = max((row_ts - prev_ts).total_seconds(), 0.0)
            delay = min(delta_sec / max(speed, 0.01), 2.0)
            await asyncio.sleep(delay)
        else:
            await asyncio.sleep(settings.fallback_stream_delay_seconds / max(speed, 0.01))

        prev_ts = row_ts if row_ts is not None else prev_ts

        payload = _build_reading_payload(row, shipment_col, temp_col, ts_col)
        prediction = model_service.predict(row)
        status, reason, risk_score, risk_level = _combine_status(payload["temperature"], prediction, settings)

        event = {
            **payload,
            **prediction,
            "status": status,
            "reason": reason,
            "risk_score": risk_score,
            "risk_level": risk_level,
            "min_temp": settings.min_temp,
            "max_temp": settings.max_temp,
        }

        db_event = {**event, "raw_features": _row_to_dict(row)}
        event["log_id"] = await asyncio.to_thread(insert_temperature_log, settings.database_path, db_event)
        firebase_result = await asyncio.to_thread(firebase_service.push_event, event)
        event["firebase_synced"] = bool(firebase_result.get("ok"))
        event["firebase_status"] = firebase_result.get("reason") or firebase_result.get("doc_id")
        if status in {"WARN", "ALERT"}:
            fcm_result = await asyncio.to_thread(firebase_service.send_alert_notification, event)
            event["fcm_sent"] = bool(fcm_result.get("ok"))
            event["fcm_status"] = fcm_result.get("reason") or f"sent={fcm_result.get('success_count', 0)}, failed={fcm_result.get('failure_count', 0)}"
        streamed_count += 1
        # Không tự export temperature_logs.csv khi stream.
        # File CSV log chỉ tạo nếu người dùng bấm /api/export.csv hoặc gọi /api/export.
        await websocket.send_json({"type": "reading", **event})

    await websocket.send_json({"type": "done", "streamed_count": streamed_count})


@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket):
    await websocket.accept()
    settings = websocket.app.state.settings
    model_service = websocket.app.state.model_service
    firebase_service = websocket.app.state.firebase_service

    try:
        msg = await websocket.receive_text()
        try:
            cfg = json.loads(msg)
        except Exception:
            cfg = {}

        speed = float(cfg.get("speed", 1.0))

        if not _require_auth_websocket(websocket, settings):
            ws_user = str(cfg.get("username", ""))
            ws_pass = str(cfg.get("password", ""))
            if not (settings.auth_required and ws_user == settings.auth_user and ws_pass == settings.auth_pass):
                await websocket.send_json({"type": "error", "message": "Unauthorized. Please login."})
                await websocket.close()
                return

        await stream_dataset(websocket, settings=settings, model_service=model_service, firebase_service=firebase_service, speed=speed)
    except WebSocketDisconnect:
        return
    except Exception as exc:
        try:
            await websocket.send_json({"type": "error", "message": str(exc)})
        except Exception:
            pass


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
