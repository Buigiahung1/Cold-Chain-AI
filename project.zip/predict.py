from __future__ import annotations

import argparse
import json
from pathlib import Path

from config import get_settings
from data_pipeline import load_dataset
from ml_model import RiskModelService


def parse_args() -> argparse.Namespace:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Predict silent failure risk for one shipment row.")
    parser.add_argument("--data", type=Path, default=settings.dataset_csv, help="Path to shipment sensor CSV.")
    parser.add_argument("--model", type=Path, default=settings.model_path, help="Model artifact path.")
    parser.add_argument("--shipment-id", type=str, default=None, help="Shipment id to score.")
    parser.add_argument("--row-index", type=int, default=0, help="Fallback row index when shipment id is not provided.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    df = load_dataset(args.data)

    if args.shipment_id is not None and "shipment_id" in df.columns:
        matches = df[df["shipment_id"].astype(str) == args.shipment_id]
        if matches.empty:
            raise SystemExit(f"Shipment not found: {args.shipment_id}")
        row = matches.iloc[0]
    else:
        row = df.iloc[args.row_index]

    service = RiskModelService(args.model)
    result = {
        "shipment_id": str(row.get("shipment_id", "")),
        "prediction": service.predict(row),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
