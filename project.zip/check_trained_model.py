from __future__ import annotations

import json
import pickle
from pathlib import Path

MODEL_PATH = Path("models/risk_model.pkl")
METRICS_PATH = Path("models/metrics.json")


def main() -> None:
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "Chưa thấy models/risk_model.pkl. Hãy chạy: python3 train_model.py"
        )

    with MODEL_PATH.open("rb") as file:
        artifact = pickle.load(file)

    pipeline = artifact.get("pipeline") if isinstance(artifact, dict) else artifact
    metadata = artifact.get("metadata", {}) if isinstance(artifact, dict) else {}
    model = pipeline.named_steps.get("model") if hasattr(pipeline, "named_steps") else pipeline

    print("Đã load được file models/risk_model.pkl")
    print(f"Thuật toán: {type(model).__name__}")
    print(f"Số cây Random Forest: {getattr(model, 'n_estimators', None)}")
    print(f"Model version: {metadata.get('model_version')}")
    print(f"Train rows: {metadata.get('train_rows')}")
    print(f"Test rows: {metadata.get('test_rows')}")
    print(f"Accuracy: {metadata.get('accuracy')}")
    print(f"F1: {metadata.get('f1')}")
    print(f"ROC-AUC: {metadata.get('roc_auc')}")

    if METRICS_PATH.exists():
        metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
        print("\nFeature columns dùng để train:")
        for col in metrics.get("feature_columns", []):
            print(f"- {col}")


if __name__ == "__main__":
    main()
