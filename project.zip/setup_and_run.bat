@echo off
setlocal

cd /d "%~dp0"

REM Mac dinh tat dang nhap de demo khong bi Unauthorized.
REM Neu muon bat dang nhap thi bo REM 2 dong duoi:
REM set COLDCHAIN_USER=ghunglatoi
REM set COLDCHAIN_PASS=ghunglatoi

REM Optional Firebase sync + FCM notification - bo REM va dien gia tri Firebase cua ban
REM set COLDCHAIN_FIREBASE_ENABLED=true
REM set COLDCHAIN_FIREBASE_CREDENTIALS=%CD%\firebase-service-account.json
REM set COLDCHAIN_FIREBASE_COLLECTION=temperature_logs
REM set COLDCHAIN_FIREBASE_ALERTS_COLLECTION=cold_chain_alerts
REM set COLDCHAIN_FIREBASE_ONLY_ALERTS=false
REM set COLDCHAIN_FIREBASE_FCM_TOKENS_COLLECTION=fcm_tokens
REM set COLDCHAIN_FIREBASE_WEB_API_KEY=your_web_api_key
REM set COLDCHAIN_FIREBASE_WEB_AUTH_DOMAIN=your_project.firebaseapp.com
REM set COLDCHAIN_FIREBASE_WEB_PROJECT_ID=your_project_id
REM set COLDCHAIN_FIREBASE_WEB_STORAGE_BUCKET=your_project.appspot.com
REM set COLDCHAIN_FIREBASE_WEB_MESSAGING_SENDER_ID=your_sender_id
REM set COLDCHAIN_FIREBASE_WEB_APP_ID=your_web_app_id
REM set COLDCHAIN_FIREBASE_WEB_VAPID_KEY=your_web_push_certificate_key_pair

set INSTALL_LOG=install_dependencies.log
set SETUP_LOG=setup_status.log

echo [%date% %time%] setup_and_run started > "%SETUP_LOG%"

powershell -NoProfile -Command "try { $client = [Net.Sockets.TcpClient]::new('127.0.0.1', 8000); $client.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
    echo [%date% %time%] Existing server found at http://localhost:8000/ >> "%SETUP_LOG%"
    echo Server dang chay san tai http://localhost:8000/
    echo Dang mo dashboard, khong tao server moi.
    start "" "http://localhost:8000/"
    exit /b 0
)

set "PYTHON_CMD="
call :try_python py -3.11
if not defined PYTHON_CMD call :try_python python
if not defined PYTHON_CMD call :try_python py -3
if not defined PYTHON_CMD call :try_python "C:\Program Files\Python311\python.exe"
if not defined PYTHON_CMD call :try_python "C:\Users\ADMIN\AppData\Local\Programs\Python\Python311\python.exe"

if not defined PYTHON_CMD (
    echo [%date% %time%] No working Python found >> "%SETUP_LOG%"
    echo Khong tim thay Python nao chay duoc tren may nay.
    echo.
    echo Cach nhanh nhat: chay install_python_and_run.bat de tai Python 3.11 roi chay lai.
    echo Hoac cai Python 3.11 thu cong, tick "Add python.exe to PATH", roi chay lai file nay.
    pause
    start "" "https://www.python.org/downloads/release/python-3119/"
    exit /b 1
)

echo Using Python:
%PYTHON_CMD% --version
echo [%date% %time%] Python command: %PYTHON_CMD% >> "%SETUP_LOG%"
%PYTHON_CMD% --version >> "%SETUP_LOG%" 2>&1

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >nul 2>&1
    if errorlevel 1 (
        echo Virtual environment cu bi loi, dang tao lai...
        echo [%date% %time%] Existing virtual environment is broken, recreating >> "%SETUP_LOG%"
        rmdir /s /q ".venv"
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    echo [%date% %time%] Creating virtual environment >> "%SETUP_LOG%"
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 (
        echo [%date% %time%] Virtual environment failed >> "%SETUP_LOG%"
        echo Khong tao duoc virtual environment.
        pause
        exit /b 1
    )
)

".venv\Scripts\python.exe" --version >> "%SETUP_LOG%" 2>&1
if errorlevel 1 (
    echo Virtual environment bi loi, dang tao lai...
    echo [%date% %time%] Virtual environment is broken, recreating >> "%SETUP_LOG%"
    rmdir /s /q ".venv"
    %PYTHON_CMD% -m venv .venv
    if errorlevel 1 (
        echo [%date% %time%] Virtual environment recreate failed >> "%SETUP_LOG%"
        echo Khong tao lai duoc virtual environment.
        pause
        exit /b 1
    )
)

".venv\Scripts\python.exe" -c "import fastapi, uvicorn, pandas, numpy, sklearn, joblib, jinja2, itsdangerous, firebase_admin" >nul 2>&1
if not errorlevel 1 (
    echo Dependencies already installed, skipping install.
    echo [%date% %time%] Dependencies already installed >> "%SETUP_LOG%"
) else (
    echo Installing dependencies...
    echo [%date% %time%] Installing dependencies >> "%SETUP_LOG%"

    ".venv\Scripts\python.exe" -c "import sys; exit(0 if sys.version_info[:2] == (3, 11) else 1)" >nul 2>&1
    if not errorlevel 1 (
        if exist "wheelhouse\*.whl" (
            echo Dang cai thu vien tu wheelhouse offline cho Python 3.11...
            echo [%date% %time%] Installing from local wheelhouse >> "%SETUP_LOG%"
            ".venv\Scripts\python.exe" -m pip install --no-index --find-links wheelhouse -r requirements.txt > "%INSTALL_LOG%" 2>&1
            if not errorlevel 1 goto deps_done
            echo Cai offline that bai, se thu cai online bang pip...
            echo [%date% %time%] Offline install failed, falling back online >> "%SETUP_LOG%"
            type "%INSTALL_LOG%"
        )
    ) else (
        echo Python khong phai 3.11, se cai online bang pip.
        echo [%date% %time%] Python is not 3.11, online install required >> "%SETUP_LOG%"
    )

    ".venv\Scripts\python.exe" -m pip install --upgrade pip setuptools wheel > "%INSTALL_LOG%" 2>&1
    if errorlevel 1 (
        echo Nang cap pip that bai. Xem file %INSTALL_LOG%.
        type "%INSTALL_LOG%"
        pause
        exit /b 1
    )

    ".venv\Scripts\python.exe" -m pip install --only-binary=:all: -r requirements.txt >> "%INSTALL_LOG%" 2>&1
    if errorlevel 1 (
        echo [%date% %time%] Dependency install failed >> "%SETUP_LOG%"
        echo Cai dependencies that bai. Xem chi tiet trong file %INSTALL_LOG%.
        type "%INSTALL_LOG%"
        echo.
        echo Neu muon cai offline, hay dung Python 3.11 vi wheelhouse trong zip la ban Windows Python 3.11.
        pause
        exit /b 1
    )
    :deps_done
    echo [%date% %time%] Dependencies installed >> "%SETUP_LOG%"
)

if not exist "models\risk_model.joblib" (
    echo Training Random Forest model...
    echo [%date% %time%] Training Random Forest >> "%SETUP_LOG%"
    ".venv\Scripts\python.exe" train_model.py
    if errorlevel 1 (
        echo [%date% %time%] Training failed >> "%SETUP_LOG%"
        echo Train model that bai.
        pause
        exit /b 1
    )
)
echo [%date% %time%] Model ready >> "%SETUP_LOG%"

powershell -NoProfile -Command "try { $client = [Net.Sockets.TcpClient]::new('127.0.0.1', 8000); $client.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
    echo [%date% %time%] Existing server found before start >> "%SETUP_LOG%"
    echo Server dang chay san tai http://localhost:8000/
    echo Dang mo dashboard, khong tao server moi.
    start "" "http://localhost:8000/"
    exit /b 0
)

echo Starting server at http://localhost:8000/
echo [%date% %time%] Starting server >> "%SETUP_LOG%"
start "" "http://localhost:8000/"
".venv\Scripts\python.exe" -m uvicorn app:app --host 0.0.0.0 --port 8000

echo [%date% %time%] Server process ended >> "%SETUP_LOG%"
pause
exit /b 0

:try_python
set "CANDIDATE=%*"
%CANDIDATE% --version >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=%CANDIDATE%"
exit /b 0
