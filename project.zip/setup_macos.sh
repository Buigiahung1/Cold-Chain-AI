#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Chưa có python3. Cài Python 3 trước rồi chạy lại."
  exit 1
fi

if [ ! -f ".env.macos" ]; then
  cp .env.macos.example .env.macos
  echo "Đã tạo .env.macos. Sau đó bạn điền Firebase Web Config/VAPID key vào file này."
fi

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo "Setup xong. Chạy ./run_macos.sh"
