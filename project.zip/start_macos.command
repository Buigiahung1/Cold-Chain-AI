#!/bin/bash
cd "$(dirname "$0")"
./run_macos.sh
