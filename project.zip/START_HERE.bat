@echo off
call setup_and_run.bat
