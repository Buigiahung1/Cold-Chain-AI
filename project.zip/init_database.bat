@echo off
setlocal

cd /d "%~dp0"

set "DB_PATH=data\cold_chain_logs.db"
set "PYTHON_CMD="

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=.venv\Scripts\python.exe"
)

if not defined PYTHON_CMD call :try_python python
if not defined PYTHON_CMD call :try_python py -3
if not defined PYTHON_CMD call :try_python "C:\Program Files\Python312\python.exe"
if not defined PYTHON_CMD call :try_python "C:\Program Files\Python311\python.exe"

if not defined PYTHON_CMD (
    echo Khong tim thay Python nao chay duoc de tao database.
    echo Hay chay setup_and_run.bat sau khi cai Python 3.11 hoac 3.12.
    pause
    exit /b 1
)

%PYTHON_CMD% -c "from database import initialize_database; initialize_database(r'%DB_PATH%'); print('Database ready:', r'%DB_PATH%')"
pause
exit /b %ERRORLEVEL%

:try_python
set "CANDIDATE=%*"
%CANDIDATE% --version >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=%CANDIDATE%"
exit /b 0
