from __future__ import annotations

import argparse
import json
import pickle
from pathlib import Path

import joblib

from config import get_settings
from ml_model import train_random_forest


def parse_args() -> argparse.Namespace:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Train Random Forest risk model from sensor_data.csv.")
    parser.add_argument("--data", type=Path, default=settings.dataset_csv, help="Path to sensor_data.csv used for training.")
    parser.add_argument("--model", type=Path, default=settings.model_path, help="Output .joblib model path used by dashboard.")
    parser.add_argument(
        "--pkl-model",
        type=Path,
        default=Path(settings.model_path).with_suffix(".pkl"),
        help="Output .pkl model path for teacher/model verification.",
    )
    parser.add_argument("--metrics", type=Path, default=settings.metrics_path, help="Output metrics JSON path.")
    parser.add_argument("--random-state", type=int, default=42, help="Random state for reproducible training.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    metrics = train_random_forest(
        dataset_csv=args.data,
        model_path=args.model,
        metrics_path=args.metrics,
        random_state=args.random_state,
    )

    # Dashboard cũ đang load file .joblib, nên giữ nguyên .joblib.
    # Đồng thời xuất thêm file .pkl để chứng minh model Random Forest đã train.
    artifact = joblib.load(args.model)
    args.pkl_model.parent.mkdir(parents=True, exist_ok=True)
    with args.pkl_model.open("wb") as file:
        pickle.dump(artifact, file)

    print("Model trained successfully from sensor_data.csv.")
    print(f"Training data: {args.data}")
    print(f"Dashboard model (.joblib): {args.model}")
    print(f"Teacher-check model (.pkl): {args.pkl_model}")
    print(f"Metrics: {args.metrics}")
    print(json.dumps(metrics, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
