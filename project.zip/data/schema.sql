CREATE TABLE IF NOT EXISTS temperature_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id TEXT,
    event_timestamp TEXT,
    temperature REAL,
    status TEXT NOT NULL,
    reason TEXT,
    risk_score REAL,
    risk_level TEXT,
    model_label INTEGER,
    model_probability REAL,
    model_version TEXT,
    source_key TEXT,
    raw_payload TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_temperature_logs_created_at
ON temperature_logs(created_at);

CREATE INDEX IF NOT EXISTS idx_temperature_logs_shipment_id
ON temperature_logs(shipment_id);

CREATE INDEX IF NOT EXISTS idx_temperature_logs_status
ON temperature_logs(status);
