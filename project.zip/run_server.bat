@echo off
setlocal

cd /d "%~dp0"

REM Mac dinh tat dang nhap de demo khong bi Unauthorized.
REM Neu muon bat dang nhap thi bo REM 2 dong duoi:
REM set COLDCHAIN_USER=ghunglatoi
REM set COLDCHAIN_PASS=ghunglatoi

REM Optional Firebase sync + FCM notification - bo REM va dien gia tri Firebase cua ban
REM set COLDCHAIN_FIREBASE_ENABLED=true
REM set COLDCHAIN_FIREBASE_CREDENTIALS=%CD%\firebase-service-account.json
REM set COLDCHAIN_FIREBASE_COLLECTION=temperature_logs
REM set COLDCHAIN_FIREBASE_ALERTS_COLLECTION=cold_chain_alerts
REM set COLDCHAIN_FIREBASE_ONLY_ALERTS=false
REM set COLDCHAIN_FIREBASE_FCM_TOKENS_COLLECTION=fcm_tokens
REM set COLDCHAIN_FIREBASE_WEB_API_KEY=your_web_api_key
REM set COLDCHAIN_FIREBASE_WEB_AUTH_DOMAIN=your_project.firebaseapp.com
REM set COLDCHAIN_FIREBASE_WEB_PROJECT_ID=your_project_id
REM set COLDCHAIN_FIREBASE_WEB_STORAGE_BUCKET=your_project.appspot.com
REM set COLDCHAIN_FIREBASE_WEB_MESSAGING_SENDER_ID=your_sender_id
REM set COLDCHAIN_FIREBASE_WEB_APP_ID=your_web_app_id
REM set COLDCHAIN_FIREBASE_WEB_VAPID_KEY=your_web_push_certificate_key_pair

powershell -NoProfile -Command "try { $client = [Net.Sockets.TcpClient]::new('127.0.0.1', 8000); $client.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
    echo Server dang chay san tai http://localhost:8000/
    echo Hay dung localhost nay, khong can tao server moi.
    start "" "http://localhost:8000/"
    goto :eof
)

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import fastapi, uvicorn, pandas, numpy, sklearn, joblib, jinja2, itsdangerous, firebase_admin" >nul 2>&1
    if not errorlevel 1 (
        start "" "http://localhost:8000/"
        ".venv\Scripts\python.exe" -m uvicorn app:app --host 0.0.0.0 --port 8000
        goto :eof
    )
    echo Virtual environment thieu thu vien, dang setup lai...
)

call setup_and_run.bat
if not errorlevel 1 goto :eof

echo Khong chay duoc server. Hay xem setup_status.log va install_dependencies.log.
pause
