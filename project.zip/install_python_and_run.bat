@echo off
setlocal

cd /d "%~dp0"

powershell -NoProfile -Command "try { $client = [Net.Sockets.TcpClient]::new('127.0.0.1', 8000); $client.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
    echo Server dang chay san tai http://localhost:8000/
    echo Dang mo dashboard, khong tao server moi.
    start "" "http://localhost:8000/"
    exit /b 0
)

set "PYTHON_VERSION=3.11.9"
set "PYTHON_URL=https://www.python.org/ftp/python/%PYTHON_VERSION%/python-%PYTHON_VERSION%-amd64.exe"
set "PYTHON_INSTALLER=%TEMP%\python-%PYTHON_VERSION%-amd64.exe"

echo Khong co Python chay duoc, dang tai Python %PYTHON_VERSION%...
echo File cai dat: %PYTHON_INSTALLER%
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%PYTHON_INSTALLER%'"
if errorlevel 1 (
    echo Tai Python that bai. Hay mo link sau va cai Python thu cong:
    echo %PYTHON_URL%
    pause
    exit /b 1
)

echo Dang cai Python %PYTHON_VERSION% cho user hien tai...
"%PYTHON_INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0
if errorlevel 1 (
    echo Cai Python that bai. Hay chay file installer nay bang tay:
    echo %PYTHON_INSTALLER%
    pause
    exit /b 1
)

echo Python da cai xong. Dang setup va chay server...
call setup_and_run.bat
exit /b %ERRORLEVEL%
