from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent


def _load_env_file(path: Path) -> None:
    """Load simple KEY=VALUE lines from .env files without adding a dependency.

    Values already present in the real shell environment are kept unchanged.
    This lets macOS users run `python -m uvicorn app:app` directly and still
    have `.env.macos` applied.
    """
    if not path.exists():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or key in os.environ:
            continue
        if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
            value = value[1:-1]
        os.environ[key] = value


# Load local env files before Settings is built. `.env.macos` is the main file
# used by the macOS runner; `.env` is accepted for people who run manually.
_load_env_file(BASE_DIR / ".env")
_load_env_file(BASE_DIR / ".env.macos")


def _is_real_env_value(value: str | None) -> bool:
    if value is None:
        return False
    text = value.strip()
    if not text:
        return False
    lowered = text.lower()
    placeholder_markers = (
        "your_",
        "your-",
        "your project",
        "your_project",
        "firebase_web_",
        "web_push_certificate",
        "...",
        "<",
        ">",
    )
    return not any(marker in lowered for marker in placeholder_markers)


@dataclass(frozen=True)
class Settings:
    dataset_csv: Path
    database_path: Path
    model_path: Path
    metrics_path: Path
    min_temp: float
    max_temp: float
    auth_user: str | None
    auth_pass: str | None
    auth_secret: str
    session_cookie: str
    model_threshold: float
    fallback_stream_delay_seconds: float
    firebase_enabled: bool
    firebase_credentials_path: Path | None
    firebase_database_url: str | None
    firebase_collection: str
    firebase_alerts_collection: str
    firebase_only_alerts: bool
    firebase_web_api_key: str | None
    firebase_web_auth_domain: str | None
    firebase_web_project_id: str | None
    firebase_web_storage_bucket: str | None
    firebase_web_messaging_sender_id: str | None
    firebase_web_app_id: str | None
    firebase_web_vapid_key: str | None
    firebase_fcm_tokens_collection: str

    @property
    def auth_required(self) -> bool:
        return self.auth_user is not None and self.auth_pass is not None

    @property
    def missing_firebase_web_push_fields(self) -> list[str]:
        required_fields = {
            "COLDCHAIN_FIREBASE_WEB_API_KEY": self.firebase_web_api_key,
            "COLDCHAIN_FIREBASE_WEB_PROJECT_ID": self.firebase_web_project_id,
            "COLDCHAIN_FIREBASE_WEB_MESSAGING_SENDER_ID": self.firebase_web_messaging_sender_id,
            "COLDCHAIN_FIREBASE_WEB_APP_ID": self.firebase_web_app_id,
            "COLDCHAIN_FIREBASE_WEB_VAPID_KEY": self.firebase_web_vapid_key,
        }
        return [name for name, value in required_fields.items() if not _is_real_env_value(value)]

    @property
    def firebase_web_push_configured(self) -> bool:
        return not self.missing_firebase_web_push_fields

    @property
    def firebase_web_config(self) -> dict[str, str | None]:
        return {
            "apiKey": self.firebase_web_api_key if _is_real_env_value(self.firebase_web_api_key) else None,
            "authDomain": self.firebase_web_auth_domain if _is_real_env_value(self.firebase_web_auth_domain) else None,
            "projectId": self.firebase_web_project_id if _is_real_env_value(self.firebase_web_project_id) else None,
            "storageBucket": self.firebase_web_storage_bucket if _is_real_env_value(self.firebase_web_storage_bucket) else None,
            "messagingSenderId": self.firebase_web_messaging_sender_id if _is_real_env_value(self.firebase_web_messaging_sender_id) else None,
            "appId": self.firebase_web_app_id if _is_real_env_value(self.firebase_web_app_id) else None,
        }


def _path_from_env(name: str, default: Path) -> Path:
    raw = os.environ.get(name)
    return Path(raw).expanduser().resolve() if raw else default.resolve()


def _bool_from_env(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _optional_path_from_env(name: str) -> Path | None:
    raw = os.environ.get(name)
    return Path(raw).expanduser().resolve() if raw else None


def _float_from_env(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def get_settings() -> Settings:
    default_firebase_credentials = BASE_DIR / "firebase-service-account.json"
    firebase_credentials_path = _optional_path_from_env("COLDCHAIN_FIREBASE_CREDENTIALS") or default_firebase_credentials.resolve()

    return Settings(
        dataset_csv=_path_from_env("COLDCHAIN_DATASET_CSV", BASE_DIR / "sensor_data.csv"),
        database_path=_path_from_env("COLDCHAIN_DB_PATH", BASE_DIR / "data" / "cold_chain_logs.db"),
        model_path=_path_from_env("COLDCHAIN_MODEL_PATH", BASE_DIR / "models" / "risk_model.joblib"),
        metrics_path=_path_from_env("COLDCHAIN_METRICS_PATH", BASE_DIR / "models" / "metrics.json"),
        min_temp=_float_from_env("COLDCHAIN_MIN_TEMP", 2.0),
        max_temp=_float_from_env("COLDCHAIN_MAX_TEMP", 8.0),
        auth_user=os.environ.get("COLDCHAIN_USER"),
        auth_pass=os.environ.get("COLDCHAIN_PASS"),
        auth_secret=os.environ.get("COLDCHAIN_AUTH_SECRET", "dev-secret-change-me"),
        session_cookie=os.environ.get("COLDCHAIN_SESSION_COOKIE", "coldchain_session"),
        model_threshold=_float_from_env("COLDCHAIN_MODEL_THRESHOLD", 0.5),
        fallback_stream_delay_seconds=_float_from_env("COLDCHAIN_STREAM_DELAY_SECONDS", 0.05),
        firebase_enabled=_bool_from_env("COLDCHAIN_FIREBASE_ENABLED", True),
        firebase_credentials_path=firebase_credentials_path,
        firebase_database_url=os.environ.get("COLDCHAIN_FIREBASE_DATABASE_URL"),
        firebase_collection=os.environ.get("COLDCHAIN_FIREBASE_COLLECTION", "temperature_logs"),
        firebase_alerts_collection=os.environ.get("COLDCHAIN_FIREBASE_ALERTS_COLLECTION", "cold_chain_alerts"),
        firebase_only_alerts=_bool_from_env("COLDCHAIN_FIREBASE_ONLY_ALERTS", False),
        firebase_web_api_key=os.environ.get("COLDCHAIN_FIREBASE_WEB_API_KEY"),
        firebase_web_auth_domain=os.environ.get("COLDCHAIN_FIREBASE_WEB_AUTH_DOMAIN"),
        firebase_web_project_id=os.environ.get("COLDCHAIN_FIREBASE_WEB_PROJECT_ID"),
        firebase_web_storage_bucket=os.environ.get("COLDCHAIN_FIREBASE_WEB_STORAGE_BUCKET"),
        firebase_web_messaging_sender_id=os.environ.get("COLDCHAIN_FIREBASE_WEB_MESSAGING_SENDER_ID"),
        firebase_web_app_id=os.environ.get("COLDCHAIN_FIREBASE_WEB_APP_ID"),
        firebase_web_vapid_key=os.environ.get("COLDCHAIN_FIREBASE_WEB_VAPID_KEY"),
        firebase_fcm_tokens_collection=os.environ.get("COLDCHAIN_FIREBASE_FCM_TOKENS_COLLECTION", "fcm_tokens"),
    )
